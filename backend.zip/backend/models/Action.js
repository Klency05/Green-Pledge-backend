const mongoose = require('mongoose');

const actionSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  pledge: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Pledge',
    required: true
  },
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    default: ''
  },
  category: {
    type: String,
    required: true,
    enum: ['waste-reduction', 'energy-saving', 'transportation', 'water-conservation', 'sustainable-living', 'nature-protection']
  },
  co2Saved: {
    type: Number,
    required: true,
    min: 0 // in kg
  },
  points: {
    type: Number,
    required: true,
    min: 1
  },
  completedAt: {
    type: Date,
    default: Date.now
  },
  verified: {
    type: Boolean,
    default: true // For MVP, auto-verify all actions
  },
  photo: {
    type: String,
    default: '' // Optional photo URL
  },
  location: {
    city: String,
    country: String
  }
}, {
  timestamps: true
});

// Index for efficient queries
actionSchema.index({ user: 1, completedAt: -1 });
actionSchema.index({ pledge: 1 });

module.exports = mongoose.model('Action', actionSchema);
