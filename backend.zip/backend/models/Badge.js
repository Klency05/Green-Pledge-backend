const mongoose = require('mongoose');

const badgeSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  icon: {
    type: String,
    required: true
  },
  color: {
    type: String,
    default: '#10B981'
  },
  category: {
    type: String,
    required: true,
    enum: ['pledge-completion', 'action-count', 'co2-saving', 'streak', 'special']
  },
  requirement: {
    type: {
      type: String,
      enum: ['pledge_complete', 'action_count', 'co2_saved', 'streak_days', 'special_achievement']
    },
    value: Number, // threshold value
    pledgeId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Pledge'
    }
  },
  rarity: {
    type: String,
    enum: ['common', 'rare', 'epic', 'legendary'],
    default: 'common'
  },
  points: {
    type: Number,
    default: 10
  },
  isActive: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Badge', badgeSchema);
