const mongoose = require('mongoose');

const pledgeSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  category: {
    type: String,
    required: true,
    enum: ['waste-reduction', 'energy-saving', 'transportation', 'water-conservation', 'sustainable-living', 'nature-protection']
  },
  duration: {
    type: Number,
    required: true, // in days
    min: 1
  },
  difficulty: {
    type: String,
    required: true,
    enum: ['easy', 'medium', 'hard']
  },
  estimatedCO2Saving: {
    type: Number,
    required: true, // in kg
    min: 0
  },
  icon: {
    type: String,
    default: '🌱'
  },
  color: {
    type: String,
    default: '#10B981'
  },
  points: {
    type: Number,
    required: true,
    min: 1
  },
  isActive: {
    type: Boolean,
    default: true
  },
  createdBy: {
    type: String,
    default: 'system'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Pledge', pledgeSchema);
