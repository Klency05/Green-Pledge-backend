const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  firebaseUid: {
    type: String,
    required: true,
    unique: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true
  },
  displayName: {
    type: String,
    required: true
  },
  photoURL: {
    type: String,
    default: ''
  },
  bio: {
    type: String,
    default: '',
    maxLength: 500
  },
  totalActions: {
    type: Number,
    default: 0
  },
  totalCO2Saved: {
    type: Number,
    default: 0 // in kg
  },
  level: {
    type: Number,
    default: 1
  },
  badges: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Badge'
  }],
  activePledges: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Pledge'
  }],
  completedPledges: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Pledge'
  }],
  joinedAt: {
    type: Date,
    default: Date.now
  },
  lastActive: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Update lastActive on every save
userSchema.pre('save', function(next) {
  this.lastActive = new Date();
  next();
});

module.exports = mongoose.model('User', userSchema);
