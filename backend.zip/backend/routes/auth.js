const express = require('express');
const admin = require('firebase-admin');
const User = require('../models/User');
const router = express.Router();

// Initialize Firebase Admin (you'll need to add your service account key)
// For MVP, we'll use a simplified approach
const serviceAccount = {
  // Add your Firebase service account credentials here
  // For now, we'll create a mock implementation
};

// Middleware to verify Firebase token
const verifyFirebaseToken = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    // For MVP demo, we'll create a simplified token verification
    // In production, use: const decodedToken = await admin.auth().verifyIdToken(token);
    
    // Mock decoded token for demo
    const decodedToken = {
      uid: 'demo-user-' + Date.now(),
      email: req.body.email || 'demo@example.com',
      name: req.body.displayName || 'Demo User'
    };

    req.user = decodedToken;
    next();
  } catch (error) {
    console.error('Token verification error:', error);
    res.status(401).json({ message: 'Invalid token' });
  }
};

// Register/Login user
router.post('/login', verifyFirebaseToken, async (req, res) => {
  try {
    const { uid, email, name } = req.user;
    
    let user = await User.findOne({ firebaseUid: uid });
    
    if (!user) {
      // Create new user
      user = new User({
        firebaseUid: uid,
        email: email,
        displayName: name,
        photoURL: req.body.photoURL || ''
      });
      await user.save();
    } else {
      // Update last active
      user.lastActive = new Date();
      await user.save();
    }

    res.json({
      message: 'Authentication successful',
      user: {
        id: user._id,
        firebaseUid: user.firebaseUid,
        email: user.email,
        displayName: user.displayName,
        photoURL: user.photoURL,
        totalActions: user.totalActions,
        totalCO2Saved: user.totalCO2Saved,
        level: user.level,
        badges: user.badges,
        joinedAt: user.joinedAt
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Login failed', error: error.message });
  }
});

// Get current user profile
router.get('/profile', verifyFirebaseToken, async (req, res) => {
  try {
    const user = await User.findOne({ firebaseUid: req.user.uid })
      .populate('badges')
      .populate('activePledges')
      .populate('completedPledges');
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({ user });
  } catch (error) {
    console.error('Profile fetch error:', error);
    res.status(500).json({ message: 'Failed to fetch profile' });
  }
});

// Update user profile
router.put('/profile', verifyFirebaseToken, async (req, res) => {
  try {
    const { displayName, bio, photoURL } = req.body;
    
    const user = await User.findOneAndUpdate(
      { firebaseUid: req.user.uid },
      { 
        displayName: displayName || req.user.name,
        bio,
        photoURL
      },
      { new: true }
    );

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({ message: 'Profile updated successfully', user });
  } catch (error) {
    console.error('Profile update error:', error);
    res.status(500).json({ message: 'Failed to update profile' });
  }
});

module.exports = router;
