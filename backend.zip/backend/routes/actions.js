const express = require('express');
const Action = require('../models/Action');
const User = require('../models/User');
const Pledge = require('../models/Pledge');
const router = express.Router();

// Get user's actions
router.get('/user/:firebaseUid', async (req, res) => {
  try {
    const user = await User.findOne({ firebaseUid: req.params.firebaseUid });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const actions = await Action.find({ user: user._id })
      .populate('pledge')
      .sort({ completedAt: -1 })
      .limit(50);

    res.json({ actions });
  } catch (error) {
    console.error('Fetch actions error:', error);
    res.status(500).json({ message: 'Failed to fetch actions' });
  }
});

// Log a new action
router.post('/', async (req, res) => {
  try {
    const { firebaseUid, pledgeId, title, description, category, co2Saved, photo } = req.body;
    
    const user = await User.findOne({ firebaseUid });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const pledge = await Pledge.findById(pledgeId);
    if (!pledge) {
      return res.status(404).json({ message: 'Pledge not found' });
    }

    // Create new action
    const action = new Action({
      user: user._id,
      pledge: pledgeId,
      title,
      description,
      category,
      co2Saved: co2Saved || pledge.estimatedCO2Saving / 7, // Default daily saving
      points: pledge.points / 7, // Daily points
      photo
    });

    await action.save();

    // Update user stats
    user.totalActions += 1;
    user.totalCO2Saved += action.co2Saved;
    await user.save();

    res.json({ 
      message: 'Action logged successfully!',
      action,
      totalActions: user.totalActions,
      totalCO2Saved: user.totalCO2Saved
    });
  } catch (error) {
    console.error('Log action error:', error);
    res.status(500).json({ message: 'Failed to log action' });
  }
});

// Get action statistics
router.get('/stats/:firebaseUid', async (req, res) => {
  try {
    const user = await User.findOne({ firebaseUid: req.params.firebaseUid });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const totalActions = await Action.countDocuments({ user: user._id });
    const totalCO2 = await Action.aggregate([
      { $match: { user: user._id } },
      { $group: { _id: null, total: { $sum: '$co2Saved' } } }
    ]);

    const actionsByCategory = await Action.aggregate([
      { $match: { user: user._id } },
      { $group: { _id: '$category', count: { $sum: 1 }, co2: { $sum: '$co2Saved' } } }
    ]);

    const recentActions = await Action.find({ user: user._id })
      .populate('pledge')
      .sort({ completedAt: -1 })
      .limit(5);

    res.json({
      totalActions,
      totalCO2Saved: totalCO2[0]?.total || 0,
      actionsByCategory,
      recentActions
    });
  } catch (error) {
    console.error('Fetch stats error:', error);
    res.status(500).json({ message: 'Failed to fetch statistics' });
  }
});

module.exports = router;
