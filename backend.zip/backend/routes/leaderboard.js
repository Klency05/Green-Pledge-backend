const express = require('express');
const User = require('../models/User');
const Action = require('../models/Action');
const router = express.Router();

// Get leaderboard by total actions
router.get('/actions', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    
    const leaderboard = await User.find()
      .select('displayName photoURL totalActions totalCO2Saved level joinedAt')
      .sort({ totalActions: -1 })
      .limit(limit);

    res.json({ leaderboard });
  } catch (error) {
    console.error('Fetch leaderboard error:', error);
    res.status(500).json({ message: 'Failed to fetch leaderboard' });
  }
});

// Get leaderboard by CO2 saved
router.get('/co2', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    
    const leaderboard = await User.find()
      .select('displayName photoURL totalActions totalCO2Saved level joinedAt')
      .sort({ totalCO2Saved: -1 })
      .limit(limit);

    res.json({ leaderboard });
  } catch (error) {
    console.error('Fetch CO2 leaderboard error:', error);
    res.status(500).json({ message: 'Failed to fetch CO2 leaderboard' });
  }
});

// Get user's rank
router.get('/rank/:firebaseUid', async (req, res) => {
  try {
    const user = await User.findOne({ firebaseUid: req.params.firebaseUid });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Get rank by actions
    const actionRank = await User.countDocuments({ 
      totalActions: { $gt: user.totalActions } 
    }) + 1;

    // Get rank by CO2 saved
    const co2Rank = await User.countDocuments({ 
      totalCO2Saved: { $gt: user.totalCO2Saved } 
    }) + 1;

    res.json({ 
      actionRank,
      co2Rank,
      totalActions: user.totalActions,
      totalCO2Saved: user.totalCO2Saved
    });
  } catch (error) {
    console.error('Fetch rank error:', error);
    res.status(500).json({ message: 'Failed to fetch user rank' });
  }
});

module.exports = router;
