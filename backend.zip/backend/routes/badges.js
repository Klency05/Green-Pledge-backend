const express = require('express');
const Badge = require('../models/Badge');
const User = require('../models/User');
const router = express.Router();

// Get all badges
router.get('/', async (req, res) => {
  try {
    const badges = await Badge.find({ isActive: true }).sort({ rarity: 1, points: 1 });
    res.json({ badges });
  } catch (error) {
    console.error('Fetch badges error:', error);
    res.status(500).json({ message: 'Failed to fetch badges' });
  }
});

// Get user's badges
router.get('/user/:firebaseUid', async (req, res) => {
  try {
    const user = await User.findOne({ firebaseUid: req.params.firebaseUid })
      .populate('badges');
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({ badges: user.badges });
  } catch (error) {
    console.error('Fetch user badges error:', error);
    res.status(500).json({ message: 'Failed to fetch user badges' });
  }
});

// Award badge to user (internal function)
router.post('/award', async (req, res) => {
  try {
    const { firebaseUid, badgeId } = req.body;
    
    const user = await User.findOne({ firebaseUid });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const badge = await Badge.findById(badgeId);
    if (!badge) {
      return res.status(404).json({ message: 'Badge not found' });
    }

    // Check if user already has this badge
    if (user.badges.includes(badgeId)) {
      return res.status(400).json({ message: 'User already has this badge' });
    }

    // Award badge
    user.badges.push(badgeId);
    await user.save();

    res.json({ 
      message: 'Badge awarded successfully!',
      badge: badge
    });
  } catch (error) {
    console.error('Award badge error:', error);
    res.status(500).json({ message: 'Failed to award badge' });
  }
});

module.exports = router;
