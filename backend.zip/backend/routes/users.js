const express = require('express');
const User = require('../models/User');
const router = express.Router();

// Get all users (for admin or public listing)
router.get('/', async (req, res) => {
  try {
    const users = await User.find()
      .select('displayName photoURL totalActions totalCO2Saved level joinedAt')
      .sort({ totalActions: -1 })
      .limit(100);

    res.json({ users });
  } catch (error) {
    console.error('Fetch users error:', error);
    res.status(500).json({ message: 'Failed to fetch users' });
  }
});

// Get user by ID
router.get('/:firebaseUid', async (req, res) => {
  try {
    const user = await User.findOne({ firebaseUid: req.params.firebaseUid })
      .populate('badges')
      .populate('activePledges')
      .populate('completedPledges');

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({ user });
  } catch (error) {
    console.error('Fetch user error:', error);
    res.status(500).json({ message: 'Failed to fetch user' });
  }
});

module.exports = router;
