const express = require('express');
const Pledge = require('../models/Pledge');
const User = require('../models/User');
const router = express.Router();

// Get all available pledges
router.get('/', async (req, res) => {
  try {
    const { category, difficulty } = req.query;
    let filter = { isActive: true };
    
    if (category) filter.category = category;
    if (difficulty) filter.difficulty = difficulty;
    
    const pledges = await Pledge.find(filter).sort({ points: 1 });
    res.json({ pledges });
  } catch (error) {
    console.error('Fetch pledges error:', error);
    res.status(500).json({ message: 'Failed to fetch pledges' });
  }
});

// Get pledge by ID
router.get('/:id', async (req, res) => {
  try {
    const pledge = await Pledge.findById(req.params.id);
    if (!pledge) {
      return res.status(404).json({ message: 'Pledge not found' });
    }
    res.json({ pledge });
  } catch (error) {
    console.error('Fetch pledge error:', error);
    res.status(500).json({ message: 'Failed to fetch pledge' });
  }
});

// Join a pledge (requires authentication)
router.post('/:id/join', async (req, res) => {
  try {
    const { firebaseUid } = req.body;
    const pledgeId = req.params.id;
    
    const user = await User.findOne({ firebaseUid });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    const pledge = await Pledge.findById(pledgeId);
    if (!pledge) {
      return res.status(404).json({ message: 'Pledge not found' });
    }
    
    // Check if user already has this pledge
    if (user.activePledges.includes(pledgeId) || user.completedPledges.includes(pledgeId)) {
      return res.status(400).json({ message: 'You have already joined this pledge' });
    }
    
    // Add pledge to user's active pledges
    user.activePledges.push(pledgeId);
    await user.save();
    
    res.json({ 
      message: 'Successfully joined pledge!',
      pledge: pledge
    });
  } catch (error) {
    console.error('Join pledge error:', error);
    res.status(500).json({ message: 'Failed to join pledge' });
  }
});

// Complete a pledge
router.post('/:id/complete', async (req, res) => {
  try {
    const { firebaseUid } = req.body;
    const pledgeId = req.params.id;
    
    const user = await User.findOne({ firebaseUid });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Move pledge from active to completed
    const pledgeIndex = user.activePledges.indexOf(pledgeId);
    if (pledgeIndex === -1) {
      return res.status(400).json({ message: 'Pledge not found in active pledges' });
    }
    
    user.activePledges.splice(pledgeIndex, 1);
    user.completedPledges.push(pledgeId);
    
    // Award points and update stats
    const pledge = await Pledge.findById(pledgeId);
    user.totalCO2Saved += pledge.estimatedCO2Saving;
    
    await user.save();
    
    res.json({ 
      message: 'Pledge completed successfully!',
      co2Saved: pledge.estimatedCO2Saving
    });
  } catch (error) {
    console.error('Complete pledge error:', error);
    res.status(500).json({ message: 'Failed to complete pledge' });
  }
});

module.exports = router;
